import java.util.*;

/**
 * Class that looks at the surronding square
 * can be extended to other games that include squares
 */
public class SmartSquare extends GameSquare {
    private boolean thisSquareHasBomb = false;
    public boolean isClicked = false;
    public static final int MINE_PROBABILITY = 10;
    public SmartSquare[] surrondingSquare = new SmartSquare[8];
    int bombCount;

    public SmartSquare(int x, int y, GameBoard board) {
        super(x, y, "resources/blank.png", board);
        Random r = new Random();

        thisSquareHasBomb = (r.nextInt(MINE_PROBABILITY) == 0);
        if (thisSquareHasBomb) {
            System.out.println("Bomb is in " + x + " " + y);
        }
    }

	/**
	 * Method run after a click has been detected
	 */
    public void clicked() {
        this.isClicked = true;
        if (thisSquareHasBomb) {
        	System.out.println("Bomb detected");
            setImage("resources/bomb.png");
            return;
        }
        check();
        recursion();
    }

	/**
	 * When a user is clicked, and it isn't a bomb
	 * will run this function to check surronding squares
	 */

	public void check() {

        surrondingSquare[0] = (SmartSquare) board.getSquareAt(xLocation + 1, yLocation);
        surrondingSquare[1] = (SmartSquare) board.getSquareAt(xLocation, yLocation + 1);
        surrondingSquare[2] = (SmartSquare) board.getSquareAt(xLocation + 1, yLocation + 1);
        surrondingSquare[3] = (SmartSquare) board.getSquareAt(xLocation - 1, yLocation + 1);
        surrondingSquare[4] = (SmartSquare) board.getSquareAt(xLocation - 1, yLocation);
        surrondingSquare[5] = (SmartSquare) board.getSquareAt(xLocation - 1, yLocation - 1);
        surrondingSquare[6] = (SmartSquare) board.getSquareAt(xLocation, yLocation - 1);
        surrondingSquare[7] = (SmartSquare) board.getSquareAt(xLocation + 1, yLocation - 1);
        bombCount = 0;

        for (SmartSquare s : surrondingSquare) {//for each for every element
            if (s != null && s.thisSquareHasBomb) {//not null to handle out of bounds exception
                bombCount++;
            }
        }
        setImage("resources/" + bombCount + ".png");

    }

  public void recursion()
  {
      for (SmartSquare a : surrondingSquare)
          {
              if(bombCount == 0 ){//if empty square
                if(a != null && !a.isClicked) {//not null to handle out of bounds exception
                  a.clicked();
                }
              }
          }
  }

}


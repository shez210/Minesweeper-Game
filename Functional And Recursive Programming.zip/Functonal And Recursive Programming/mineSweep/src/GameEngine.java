/**
 * Created by faisals1 on 04/11/2016.
 */
/*public class GameEngine  {

    public GameEngine() {
        clicked();
    }

    public void clicked() {
        if(thisSquareHasBomb)
        {
            setImage("resources/bomb.png");

        }
    }


}
*/


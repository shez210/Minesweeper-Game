-module(toh).
-export([create_towers/1, display_towers/1, move/3, solve/3]).

create_towers(N) ->
	[create_tower_one(N),create_tower_one(0), create_tower_one(0)].
	create_tower_one(0) -> [];
	create_tower_one(N) -> [N | create_tower_one(N-1)].
	
display_towers(X) ->
	[Tower1, Tower2, Tower3] = X,
	io : format("-------------------~n"),
	io : format("tower 1: ~w ~n",[Tower1]  ),
	io : format("tower 2: ~w ~n", [Tower2] ),
	io : format("tower 3: ~w ~n", [Tower3] ),
	io : format("-------------------~n").
	
move(From, To, Via) ->
	LastFrom = [lists:last(From)],
	NewTo = lists:append(To, LastFrom),
	NewFrom = lists:droplast(From),
	L = [NewFrom, Via, NewTo],
	display_towers(L).

solve(From, To, Via) ->
	LastFrom = lists:last(From),
	NewTo = [lists:append(To, LastFrom)],
	NewFrom = lists:droplast(From),
	L = [NewFrom, Via, NewTo],
	display_towers(L),
	solve(NewFrom, NewTo, Via).







-module(hanoi).
-export([hanoi/1]).

hanoi(N) when N < 1 -> [];
hanoi(N) -> hanoi(N, a, b, c).

hanoi(1, A, _, C) -> [{A, C}];
hanoi(N, A, B, C) ->
    hanoi(N-1, A, C, B) ++ [{A, C}] ++ hanoi(N-1, B, A, C).
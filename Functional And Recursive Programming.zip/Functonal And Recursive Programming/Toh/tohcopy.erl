-module(toh).
-export([create_towers/1, display_towers/1, move/4]).

create_towers(N) ->
	Towers =[create_tower_one(N),create_tower_one(0), create_tower_one(0)].
	
	create_tower_one(0) -> [];
	create_tower_one(N) -> [N | create_tower_one(N-1)].
	
display_towers(X) ->
	[Tower1, Tower2, Tower3] = X,
	io : format("-------------------~n"),
	io : format("tower 1: ~w ~n",[Tower1]  ),
	io : format("tower 2: ~w ~n", [Tower2] ),
	io : format("tower 3: ~w ~n", [Tower3] ),
	io : format("-------------------").

move(1, F, T, V) ->
	io:format("move ~p disk to ~w~n", [F , T]);
	move(N, F, T, V) ->
	move(N-1, F, V, T),
	move(1, F, T, V),
	move(N-1, V, T, F),
	display_towers().